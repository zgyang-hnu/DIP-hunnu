# DIP
This repo. provides the code used for "Domain-invariant prototypes for semantic segmentation"
